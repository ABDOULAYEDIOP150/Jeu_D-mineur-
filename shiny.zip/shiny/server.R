
library(shiny)

shinyServer(function(input, output) {
output$gen_matrice<-renderTable({
  nb_ligne=9
  nb_colon=9
  Mat<-matrix(0,nb_ligne,nb_colon)
  Mat
})

})

