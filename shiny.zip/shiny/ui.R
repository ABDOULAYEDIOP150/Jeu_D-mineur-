ui <- dashboardPage(
  dashboardHeader(title="Projet_Demineur"),
  dashboardSidebar(
    menuItem("MATRICE",tabName ="mat" )
  ),
  dashboardBody(
    tabItems(
      tabItem("mat",tableOutput("gen_matrice"))
    )
  )
)