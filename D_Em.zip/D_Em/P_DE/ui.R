library(shinydashboard)
ui <- dashboardPage(
  dashboardHeader(title="Projet_Demineur"),
  dashboardSidebar(
    # on peut ne peut ne pas mettre le démineur  sur le menu mais c'est juste pour montrer comment marche le code Par ce que normalement le joueur ne doit pas voir le démineur au moment ou il  jouer 
    menuItem("Démineur",tabName ="mat" ),
    menuItem("Jouer()",tabName = "m"),
    menuItem("Nbre_mines_Adjace",tabName = "n"),
    menuItem("le_jeu",tabName = "p")
  ),
  dashboardBody(
    tabItems(
      tabItem("mat",
              tableOutput("gen_matrice")),
      tabItem("m",
              numericInput("a","choisir la ligne compris entre 1 et 24" ,value =10, min = 1,max = 24),
              numericInput("b","choisir la colonne compris entre 1 et 20" ,value=2, min = 1,max = 20),
              textOutput("ggg")),
      tabItem("n",textOutput("nbre_mines_adj")),
      tabItem("p",textOutput("le_jeu"))
    )
  )
)