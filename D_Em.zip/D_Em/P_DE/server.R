shinyServer(function(input, output) {
  output$gen_matrice<-renderTable({
    plateau<-creation_plateau(24,20,40)
    plateau
    
  })
  output$ggg<-renderText({
    val<-check_spot(input$a,input$b)
    if (val == "mine") {
      print("Boom! Game over, la parie est terminé ")
    } else {
      "clear"
      
    }
    
    
    
  })
  output$nbre_mines_adj<-renderText({
    w<-calculer_mines_adjacentes(plateau,input$a,input$b)
    w
  })
  output$le_jeu<-renderText({
    jouer()
  })
})
