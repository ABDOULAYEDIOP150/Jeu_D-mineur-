shinyServer(function(input, output) {
  output$gen_matrice<-renderTable({
    grid_size <- 10
    num_mines <- 10
    # Créer la grille
    grid <- matrix(0, nrow = grid_size, ncol = grid_size)
    
    # Placer les mines
    mine_spots <- sample(1:grid_size^2, num_mines)
    grid[mine_spots] <- "X"
    grid
    
  })
  
  output$ggg<-renderText({
    check_spot <- function(row, col) {
      grid_size <- 10
      num_mines <- 10
      # Créer la grille
      grid <- matrix(0, nrow = grid_size, ncol = grid_size)
      
      # Placer les mines
      mine_spots <- sample(1:grid_size^2, num_mines)
      grid[mine_spots] <- "X"
      
      
      
      if (grid[row, col] == "X") {
        return("mine")
      } else {
        return("clear")
      }
    }
    
    val<-check_spot(input$a,input$b)
    
    if (val == "mine") {
      "Boom! Game over"
      # cat("Boom! Game over.\n")
    } else {
      "clear"
      # grid[row, col] <- 1
      # print_grid(grid)
      # cat("Clear!\n")
    }

    
    
  })
  
})
