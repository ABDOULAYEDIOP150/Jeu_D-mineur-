ui <- dashboardPage(
  dashboardHeader(title="Projet_Demineur"),
  dashboardSidebar(
    menuItem("MATRICE",tabName ="mat" ),
    menuItem("Text",tabName = "m")
  ),
  dashboardBody(
    tabItems(
      tabItem("mat",
              tableOutput("gen_matrice")),
      tabItem("m",
              numericInput("a","choisir la ligne compris entre 1 et 10" ,value =2, min = 1,max = 10),
              numericInput("b","choisir la colonne compris entre 1 et 10" ,value=2, min = 1,max = 10),
              textOutput("ggg"))
    )
  )
)