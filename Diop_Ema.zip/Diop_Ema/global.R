library(shinydashboard)
library(shiny)
check_spot <- function(row, col) {
  grid_size <- 10
  num_mines <- 10
  # Création de grille vide 
  grid <- matrix(0, nrow = grid_size, ncol = grid_size)
  
  # Placer les mines aléatoirement 
  mine_spots <- sample(1:grid_size^2, num_mines)
  grid[mine_spots] <- "X"
  
  
  
  if (grid[row, col] == "X") {
    return("mine")
  } else {
    return("clear")
  }
}


